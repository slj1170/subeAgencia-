<?php
    $message_sent = true;

    if(isset($_POST['email']) && $_POST['email'] != ''){
        //Checking if there is an email

        if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
            //Checking if the email is valid

            //Form Submit
            $userName = $_POST['name'];
            $userEmail = $_POST['email'];
            $userPhone = $_POST['phone'];
            $company = $_POST['company'];
            $years = $_POST['years'];
            $marketing = $_POST['marketing'];
            $comment = $_POST['comment'];
            
            //Sending email to self and administrator
            $array = array($userEmail, "adminstrator@email.com");
            $to = implode(", ",$array);

            $subject = "Contacted from Landing Page";
            $body = "";
     
            $body .= "From: ".$userName. "\r\n";
            $body .= "Email: ".$userEmail. "\r\n";
            $body .= "Phone: ".$userPhone. "\r\n";
            $body .= "Company Name: ".$company. "\r\n";
            $body .= "Years in the market that your company has: ".$years. "\r\n";
            $body .= "Have you already done Digital marketing campaigns?: ".$marketing. "\r\n";
            $body .= "Comments: ".$comment. "\r\n";
     
            mail($to,$subject,$body);
            

            $message_sent = true;
        }

    }
    if($message_sent){
        header('Location: ../thankyou.html');
    }
    else{
        header('Location: ../index.php');
    }


?>