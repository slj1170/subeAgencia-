// JavaScript Document
var $lp = jQuery.noConflict();

$lp(document).ready(function() {
	
});